//
//  ToDoViewModel.swift
//  ToDolist
//
//  Created by Tomiris on 28.04.2022.
//

import Foundation
import RealmSwift

class ToDoViewModel: NSObject {
    static var sharedInstance = ToDoViewModel()
    var chores = [Chore]()
    typealias completionHandler = () -> Void
    let realm = try! Realm()
    
    func addChore(chore: Chore, completion: completionHandler) {
        self.realm.beginWrite()
        self.realm.add(chore)
        try! self.realm.commitWrite()
        print("Saved!")
        completion()
    }
    
    func editChore(chore: Chore, updatedChore: Chore, completion: completionHandler) {
        self.realm.beginWrite()
        self.realm.delete(chore)
        self.realm.add(updatedChore)
        try! self.realm.commitWrite()
       
    }
    
    func deleteChore(chore: Chore, choreIndex: Int, completion: completionHandler){
        self.realm.beginWrite()
        self.realm.delete(chore)
        try! self.realm.commitWrite()
        chores.remove(at: choreIndex)
        completion()
    }
    
    func loadChores(completion: completionHandler) {
        self.realm.beginWrite()
        let savedChores = self.realm.objects(Chore.self)
        self.chores.removeAll()
        self.chores.append(contentsOf: savedChores)
        try! self.realm.commitWrite()
    }
    
}
