//
//  EditChoreViewController.swift
//  ToDolist
//
//  Created by Tomiris on 28.04.2022.
//

import UIKit
import RealmSwift

class EditChoreViewController: UIViewController {
    
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBAction func saveButton(_ sender: Any){
        
        let newChore = Chore(
            name: name.text ?? "",
            time: datePicker.date)
        vm.editChore(chore: self.chore!, updatedChore: newChore){
            print("Saved")
            navigationController?.popViewController(animated: true)
        }
        
    }
    
    @IBAction func deleteButton(_ sender: Any){
        vm.deleteChore(chore: self.chore!, choreIndex: self.index!){
            print("Deleted")
            navigationController?.popViewController(animated: true)
        }
    }
    
    var chore: Chore?
    var index: Int?
    
    let vm = ToDoViewModel.sharedInstance

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let myChore = self.chore {
            name.text = myChore.name
            datePicker.date = myChore.time
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
