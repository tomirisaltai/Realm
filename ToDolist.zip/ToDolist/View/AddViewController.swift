//
//  AddViewController.swift
//  ToDolist
//
//  Created by Tomiris on 28.04.2022.
//

import UIKit
import RealmSwift

class AddViewController: UIViewController {
    
    @IBOutlet weak var txtChoreName: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBAction func saveButton(_ sender: Any){
        let chore = Chore(name: txtChoreName.text ?? "", time: datePicker.date)
        let vm = ToDoViewModel.sharedInstance
        vm.addChore(chore: chore) {
            self.navigationController?
                .popViewController(animated: true)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
